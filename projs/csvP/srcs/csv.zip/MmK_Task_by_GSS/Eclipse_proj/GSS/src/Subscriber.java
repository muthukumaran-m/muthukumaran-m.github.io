import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.Scanner;

/**
 * @author Muthukumaran Muthiah
 **/
public class Subscriber {
	// Date variables.
	static Date sDate, rDate, offDate, tDate;
	// int variables.
	static int offPayment;
	// String variables.
	static String recurringDate, offPaymentDate, subscribedDate, name;
	// List of Months in a year.
	static String[] months = { "January", "February", "March", "April", "May", "June", "July", "August", "September",
			"October", "November", "December" };

	@SuppressWarnings({ "deprecation", "resource" })
	// main method starts.
	public static void main(String[] args) {
		// Consider today date as 31st July as per the requirement.
		String today = "31/07/2018";
		// ParseException handling.
		try {
			// parsing the string to date object.
			tDate = new SimpleDateFormat("dd/MM/yyyy").parse(today);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		// Scanner object created for getting the user input.
		Scanner scan = new Scanner(System.in);

		// Code to get the subscriber name and store it into the name variable.
		System.out.println("Enter The Subscriber's Name");
		name = scan.nextLine();

		/*
		 * Code to get the subscribed date and store it into the subscribedDate
		 * variable.
		 */
		System.out.println("Enter The Subscribed Date (DD/MM/YYYY) ex: 13/01/2018");
		subscribedDate = scan.nextLine();
		// ParseException handling.
		try {
			// parsing the string to date object
			sDate = new SimpleDateFormat("dd/MM/yyyy").parse(subscribedDate);
		} catch (ParseException e) {
			e.printStackTrace();
		}

		/*
		 * Code to get the recurring dates and store them into the rDates(list)
		 * variable.
		 */
		ArrayList<Date> rDates = new ArrayList<Date>();
		System.out.println("Do You Want To Add Recurring Date: (Y / N)");
		// Getting multiple recurring dates from user.
		for (String choice = scan.nextLine(); choice.equalsIgnoreCase("y"); choice = scan.nextLine()) {
			System.out.println("Enter The Recurring Date (DD/MM/YYYY) ex: 13/01/2018");
			recurringDate = scan.nextLine();
			// ParseException handling.
			try {
				// parsing the string to date object
				rDate = new SimpleDateFormat("dd/MM/yyyy").parse(recurringDate);
				// Adding the recurring dates into a list.
				rDates.add(rDate);
			} catch (ParseException e) {
				e.printStackTrace();
			}
			System.out.println("Do You Wanna Add More Recurring Date (Y / N)");
		} // End of for
			// Checking Subscription month and recurring months same or not.
		String sameMonthRecur = "No";
		for (Date d : rDates) {
			if (sDate.getMonth() == d.getMonth()) {
				sameMonthRecur = "Yes";
			}
		}
		// Code to get the Off-payment and store it into the offPayment variable.
		if (sameMonthRecur.equals("No")) {
			System.out.println("Enter The Offpayment (4 * Months of subscription + 1)");
			offPayment = scan.nextInt();
			if (offPayment != 0) {
				while (offPayment % 4 != 1 || offPayment == 1) {
					// Checking for the valid price.
					System.err.println("Enter a valid amount (4 * Months of subscription + 1)");
					offPayment = scan.nextInt();
				} // end of while
			}
			/*
			 * Code to get the offPaymentDate and store it into the offPaymentDate variable,
			 * if the offPayment value is 0 means no need of getting the offPaymentDate.
			 */
			if (offPayment != 0) {
				System.out.println("Enter The Off-payment Date (DD/MM/YYYY) ex: 13/01/2018");
				scan.nextLine();
				offPaymentDate = scan.nextLine();
				// ParseException handling.
				try {
					// parsing the string to date object
					offDate = new SimpleDateFormat("dd/MM/yyyy").parse(offPaymentDate);
				} catch (ParseException e) {
					e.printStackTrace();
				}
			}
		}

		System.out.println("\n***User Status***");
		// Code to display subscriber name in the first line.
		System.out.println(name.toUpperCase() + " Subscribed In " + months[sDate.getMonth()]);

		// Code to display the offPayment month and offPayment in Second.
		if (sameMonthRecur.equals("No") && offPayment != 0) {
			String d = Integer.toString(offDate.getDate());
			System.out.print(d);
			if (offDate.getDate() > 10 && offDate.getDate() < 20) {
				System.out.print("th ");
			} else if (d.endsWith("1")) {
				System.out.print("st ");
			} else if (d.endsWith("2")) {
				System.out.print("nd ");
			} else if (d.endsWith("3")) {
				System.out.print("rd ");
			} else {
				System.out.print("th ");
			}

			System.out.print(months[offDate.getMonth()] + " one-off payment of $" + offPayment + "\n");
		}

		// Code to display the recurring dates in consecutive lines.
		for (Date rd : rDates) {
			String redcDat = Integer.toString(rd.getDate());
			System.out.print(redcDat);
			if (rd.getDate() > 10 && rd.getDate() < 20) {
				System.out.print("th ");
			} else if (redcDat.endsWith("1")) {
				System.out.print("st ");
			} else if (redcDat.endsWith("2")) {
				System.out.print("nd ");
			} else if (redcDat.endsWith("3")) {
				System.out.print("rd ");
			} else {
				System.out.print("th ");
			}
			System.out.print(months[rd.getMonth()] + " Recurring Payment\n");
		} // End of for each

		// Determine and Displaying the subscriber's status
		// deduct the sub-charge of one offpayment.
		offPayment--;
		// find the lastPayment month from the.
		int lastPaymentMonth;
		try {
			lastPaymentMonth = Collections.max(rDates).getMonth();
		} catch (Exception e) {
			lastPaymentMonth = 0;
		}
		// checks isPaymentMadeOrNot previously
		if (offPayment == -1 && rDates.size() == 0) {
			System.out.println("No Payments to date");

		}
		// Checking for Fully Paid status.
		/*
		 * Fully paid if the last payment month is same as the current month or the off
		 * payment is greater than or equal to the (no. of months from the subscription
		 * 4).
		 */
		if (tDate.getMonth() == lastPaymentMonth || (tDate.getMonth() - sDate.getMonth()) * 4 <= offPayment) {
			System.out.println("\nSubscriber Status FULLY PAID");
			return;
		}
		// Checking for Over-Due status
		/*
		 * Over-Due if there is no payment since the last two months or subscribed in
		 * the same month without any payments subscribed within two previous months
		 * without any payments.
		 */
		if (tDate.getMonth() - lastPaymentMonth <= 2 || sDate.getMonth() == tDate.getMonth()
				|| tDate.getMonth() - sDate.getMonth() < 2) {
			System.out.println("\nSubscriber Status OVER DUE");
			return;
		}
		// Checking for DISABLED status 
		/*
		 * Disables if there is no payment more than two months or the off payment is
		 * less than the (no. of months from the subscription * 4), or subscribed before
		 * two months without any payments.
		 */
		if (tDate.getMonth() - lastPaymentMonth > 2 || (tDate.getMonth() - sDate.getMonth()) * 4 > offPayment
				|| tDate.getMonth() - sDate.getMonth() >= 2) {
			System.out.println("\nSubscriber Status DISABLED");
			return;
		}
	}// End of main method
}
